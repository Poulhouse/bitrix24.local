<?php namespace Kplab\Exchange_log\Helpers;

use Kplab\Exchange_log\ExchangeLogTable;
use Bitrix\Main\Type\DateTime;
use KPLab\Logs\File;

class Log
{
    public static function init(
        int $entityTypeId,
        int $entityId,
        string $fieldCode,
        string $fieldName,
        string $newValue,
        array $context = [],
        string $logPath = LOG_ChangeChecker
    ): void {
        try {
            $lastLog = ExchangeLogTable::getList([
                'filter' => [
                    'ENTITY_TYPE_ID' => $entityTypeId,
                    'ENTITY_ID'      => $entityId,
                    'FIELD_CODE'     => $fieldCode,
                ],
                'order' => ['CHANGE_DATE' => 'DESC'],
                'limit' => 1,
            ])->fetch();

            $oldValue = $lastLog['NEW_VALUE'] ?? '';

            if ($oldValue === $newValue) {
                return;
            }

            $data = [
                'ENTITY_TYPE_ID' => $entityTypeId,
                'ENTITY_ID'      => $entityId,
                'FIELD_CODE'     => $fieldCode,
                'FIELD_NAME'     => $fieldName,
                'OLD_VALUE'      => $oldValue,
                'NEW_VALUE'      => $newValue,
                'USER_ID'        => $context['USER_ID'],
                'CHANGE_DATE'    => new DateTime(),
            ];

            if (isset($context['SERVICE_UPDATE_NAME'])) {
                $data['SERVICE_UPDATE_NAME'] = $context['SERVICE_UPDATE_NAME'];
            }

            $result = ExchangeLogTable::add($data);

            if (!$result->isSuccess()) {
                File::AddMessage("Ошибка при добавлении лога изменения поля", [
                    'errors' => $result->getErrorMessages(),
                    'data' => $data,
                ], $logPath);
            }

        } catch (\Throwable $e) {
            File::AddMessage([
                'exception' => $e,
                'entityTypeId' => $entityTypeId,
                'entityId' => $entityId,
                'fieldCode' => $fieldCode,
                'newValue' => $newValue,
                'context' => $context,
            ],"Ошибка в Log::init", $logPath);
        }
    }
}