<?php
namespace Kplab\Exchange_log\Helpers;

use Bitrix\Main\ArgumentException;
use Bitrix\Main\ObjectPropertyException;
use Bitrix\Main\SystemException;
use Bitrix\Main\Type\DateTime;
use Bitrix\Main\Config\Option;
use Kplab\Exchange_log\ExchangeLogTable;
use KPLab\Logs;
use Kplab\Exchange_log\Service\FieldMeta;

define("LOG_ChangeChecker", $_SERVER['DOCUMENT_ROOT']."/local/logs/ChangeChecker.log");

class ChangeChecker
{
    public static function check(array $newData, int $entityTypeId, int $entityId, array $context = []): void
    {
        $moduleId = 'kplab.exchange_log';

        // Получаем сохранённые настройки для стандартных и смарт-процессов
        $trackedSettingsJson = Option::get($moduleId, "tracked_general_entities", '{}');
        $trackedSpSettingsJson = Option::get($moduleId, "tracked_sp_entities", '{}');

        $trackedSettings = json_decode($trackedSettingsJson, true) ?: [];
        $trackedSpSettings = json_decode($trackedSpSettingsJson, true) ?: [];

        // Объединяем
        $tracked = $trackedSettings + $trackedSpSettings;

        // Извлекаем список отслеживаемых полей для данной сущности
        $fieldsMap = $tracked[$entityTypeId] ?? [];

        Logs\File::AddMessage($fieldsMap , "chack", LOG_ChangeChecker);

        // Проверка групповых полей
        foreach (['REQUISITES','contactDetails', 'addressDetails', 'bankDetails'] as $groupCode) {
            if (array_key_exists($groupCode, $fieldsMap)) {
                match ($groupCode) {
                    'REQUISITES' => self::checkRequisitesChanges($entityTypeId, $entityId, $context),
                    'contactDetails' => self::checkContactDetailsChanges($newData, $entityTypeId, $entityId, $context),
                    'addressDetails' => self::checkAddressChanges($entityTypeId, $entityId, $context),
                    'bankDetails'    => self::checkBankDetailsChanges($entityTypeId, $entityId, $context),
                };
            }
        }

        // Исключаем логические группы
        $skipGroups = ['contactDetails', 'addressDetails', 'bankDetails', 'REQUISITES'];

        $simpleFieldsMap = array_diff_key($fieldsMap, array_flip($skipGroups));
        FieldMeta::get($entityTypeId);
        self::checkSimpleFields($newData, $entityTypeId, $entityId, array_keys($simpleFieldsMap), $context);
    }
    public static function checkRequisitesChanges(int $entityTypeId, int $entityId, array $context = []): void
    {
        try {
            $details = Requisites::getRequisites($entityId);

            $newFormatted = json_encode($details, JSON_UNESCAPED_UNICODE);

            $fieldCode = 'REQUISITES';
            $fieldName = 'Основные реквизиты (REQUISITES)';

            Log::init(
                $entityTypeId,
                $entityId,
                $fieldCode,
                $fieldName,
                $newFormatted,
                $context,
                LOG_ChangeChecker
            );

        } catch (\Throwable $e) {
            Logs\File::AddMessage([
                'exception' => $e,
                'entityTypeId' => $entityTypeId,
                'entityId' => $entityId,
                'context' => $context,
            ],"Ошибка в checkRequisitesChanges: " . $e->getMessage(), LOG_ChangeChecker);
        }
    }
    public static function checkBankDetailsChanges(int $entityTypeId, int $entityId, array $context = []): void
    {
        try {
            $banks = BankDetails::loadBankDetails($entityId);
            $banksNominal = BankDetails::loadBankNominalDetails($entityId);

            $details = [];
            if (!empty($bank)) {
                $details[] = self::formatBankDetail($banks, 'Расчетный счет');
            }
            if (!empty($bankNominal)) {
                $details[] = self::formatBankDetail($banksNominal, 'Номинальный счет');
            }

            $newFormatted = json_encode($details, JSON_UNESCAPED_UNICODE);

            $fieldCode = 'BANKING_DETAILS';
            $fieldName = 'Банковские реквизиты (bankDetails)';

            Log::init(
                $entityTypeId,
                $entityId,
                $fieldCode,
                $fieldName,
                $newFormatted,
                $context,
                LOG_ChangeChecker
            );

        } catch (\Throwable $e) {
            Logs\File::AddMessage("Ошибка в checkBankDetailsChanges: " . $e->getMessage(), [
                'exception' => $e,
                'entityTypeId' => $entityTypeId,
                'entityId' => $entityId,
                'context' => $context,
            ], LOG_ChangeChecker);
        }
    }
    public static function checkAddressChanges(int $entityTypeId, int $entityId, array $context = []): void
    {
        try {
            $newAddress = AddressHelper::getNormalizedAddressArray($entityId);

            if (empty($newAddress)) {
                return;
            }

            foreach ($newAddress as $type => $newFormatted) {
                $label = ($type === 'FACT') ? 'Фактический адрес' : 'Адрес регистрации';
                $fieldCode = "ADDRESS_" . strtoupper($type); // e.g., ADDRESS_FACT
                $fieldName = "Адреса ({$label})(addressDetails)";

                Log::init(
                    $entityTypeId,
                    $entityId,
                    $fieldCode,
                    $fieldName,
                    $newFormatted,
                    $context,
                    LOG_ChangeChecker
                );
            }
        } catch (\Throwable $e) {
            Logs\File::AddMessage([
                'exception' => $e,
                'entityTypeId' => $entityTypeId,
                'entityId' => $entityId,
                'context' => $context,
            ], "Ошибка в checkAddressChanges: " . $e->getMessage(),LOG_ChangeChecker);
        }
    }
    public static function checkContactDetailsChanges(array $newData, int $entityTypeId, int $entityId, array $context = []): void
    {
        try {
            $contactDetails = ContactHelper::extractAllContactDetails($newData);

            foreach ($contactDetails as $fieldCode => $entries) {
                if (empty($entries)) {
                    continue;
                }

                $labels = [
                    'PHONE' => 'Телефоны',
                    'EMAIL' => 'Email',
                    'IM'    => 'Мессенджеры',
                    'WEB'   => 'Веб-сайты',
                ];
                $label = $labels[$fieldCode] ?? $fieldCode;

                // Если только один тип — включим его в имя поля
                $types = array_unique(array_column($entries, 'VALUE_TYPE'));
                $typeLabel = (count($types) === 1 && $types[0] !== '')
                    ? ' — ' . ContactHelper::getValueTypeLabel($types[0], $fieldCode)
                    : '';

                $fieldName = "Контактные данные ({$label}{$typeLabel})(contactDetails)";
                $newJson = json_encode($entries, JSON_UNESCAPED_UNICODE);

                Log::init(
                    $entityTypeId,
                    $entityId,
                    $fieldCode,
                    $fieldName,
                    $newJson,
                    $context
                );
            }

        } catch (\Throwable $e) {
            \KPLab\Logs\File::AddMessage([
                'exception' => $e,
                'entityTypeId' => $entityTypeId,
                'entityId' => $entityId,
                'context' => $context,
                'newData' => $newData,
            ], "Ошибка в checkContactDetailsChanges: " . $e->getMessage(),LOG_ChangeChecker);
        }
    }

    public static function checkSimpleFields(
        array $newData,
        int $entityTypeId,
        int $entityId,
        array $fieldsToCheck,
        array $context = []
    ): void
    {
        try {
            foreach ($fieldsToCheck as $fieldCode) {
                if (!isset($newData[$fieldCode])) {
                    continue;
                }

                $fieldTitle = FieldMeta::getTitle($entityTypeId, $fieldCode);
                $fieldName = "{$fieldTitle}";

                $newValue = is_array($newData[$fieldCode])
                    ? json_encode($newData[$fieldCode], JSON_UNESCAPED_UNICODE)
                    : $newData[$fieldCode];

                Log::init(
                    $entityTypeId,
                    $entityId,
                    $fieldCode,
                    $fieldName,
                    $newValue,
                    $context
                );
            }
        } catch (\Throwable $e) {
            \KPLab\Logs\File::AddMessage([
                'exception' => $e,
                'entityTypeId' => $entityTypeId,
                'entityId' => $entityId,
                'fieldsToCheck' => $fieldsToCheck,
                'context' => $context,
                'newData' => $newData,
            ], "Ошибка в checkSimpleFields: " . $e->getMessage(), LOG_ChangeChecker);
        }
    }


    private static function formatBankDetail(array $bankDetails, string $label): array
    {
        $return = [];
        foreach ($bankDetails as $bankDetail) {
            $return[] = [
                'Основной счет' => $bankDetail['UF_CRM_PRIMARY_TXT'] ?? 'Нет',
                'Тип счета' => $bankDetail['UF_CRM_BD_ACC_TYPE'],
                'Наименование счета' => $bankDetail['NAME'] ?? $label,
                'Наименование банка' => $bankDetail['RQ_BANK_NAME'] ?? '',
                'Адрес банка'        => $bankDetail['RQ_BANK_ADDR'] ?? '',
                'БИК'                => $bankDetail['RQ_BIK'] ?? '',
                'Расчетный счёт'     => $bankDetail['RQ_ACC_NUM'] ?? '',
                'Валюта счёта'       => $bankDetail['RQ_ACC_CURRENCY'] ?? '',
                'Кор. счёт'          => $bankDetail['RQ_COR_ACC_NUM'] ?? '',
                'Комментарий'        => $bankDetail['COMMENTS'] ?? '',
            ];
        }
        return $return;
    }
}
